var emailid = document.querySelector("#email");
var paswd = document.querySelector("#password");

var email_err = document.querySelector("#emailerror");
var pas_error = document.querySelector("#paswderror");

emailid.addEventListener("keyup",verifyemail);

let reg_email =  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

function verifyemail()
{
    if(!reg_email.test(emailid.value)){
        email_err.innerHTML="please enter a valid email address";
        emailid.style.border="2px solid red";
        email_err.style.color="red";
        email_err.style.fontSize="x-small";
        return false;
    }
    else{
        email_err.style.color="black";
        email_err.innerHTML=" ";
        emailid.style.border="2px solid green";
        return true;
    
    }   
}


function validatepaswd()
{
    if(paswd.value.length < 8)
    {
    pas_error.innerHTML="Invalid password";
    paswd.style.border="2px solid red";
    pas_error.style.fontSize="x-small";
    return false;
    }
    else{
        pas_error.innerHTML="";
        paswd.style.border="2px solid green";
        return true;

    }
}
