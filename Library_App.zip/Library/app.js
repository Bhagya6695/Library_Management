const express = require("express");
const app = express();


const nav =[
    {
        link:'/books',name:'Books'
    },
    
    {
        link:'/authors',name:'Authors'
    },

    {
        link:'/contact',name:'Contact'
    },

    {
        link:'/addbook',name:'AddBook'
    }
    
    

];

const booksRouter = require('./src/routes/bookRoutes')(nav);
const authorRouter = require('./src/routes/authorRoutes')(nav);
const loginRouter = require('./src/routes/loginRoutes')(nav);
const signupRouter = require('./src/routes/signupRoutes')(nav);
const addbookRouter =  require('./src/routes/addbookRoutes')(nav);
const contactRouter =  require('./src/routes/contactRoutes')(nav);




app.use(express.static('./public'));
app.set('view engine','ejs');
app.set('views','./src/views');
app.use('/books',booksRouter);
app.use('/authors',authorRouter);
app.use('/login',loginRouter);
app.use('/signup',signupRouter);
app.use('/addbook',addbookRouter);
app.use('/contact',contactRouter);







app.get('/',function(req,res){
    res.render("index",
    {
        nav,
        title:'Library',
        details
    });
});

var details = [
    {
        comment: 'Repurpose Content to Reach a Wider Audience',
        url:'97thfloor.com',
        posted: '2 hours ago',
        img :'97.png'

    },
    {
        comment: 'Showcase and Discover Creative Work',
        url:'behance.net',
        posted: 'Yesterday',
        img :'behan.jpeg'

    },
    {
        comment: 'Discover the  Largest Online Art Gallery',
        url:'devianart.com',
        posted: 'Yesterday',
        img :'devian.png'

    },
    {
        comment: 'TrendPaper - Whats Trending in the World',
        url:'betalist.com',
        posted: 'Last Week',
        img :'betalist.png'

    },
    {
        comment: 'Best Web-site designs that Inspire You',
        url:'blog.hubspot.com',
        posted: 'Last Week',
        img :'blog.jpeg'

    }

]



app.listen(3339,function(){
    console.log("server is listening!!!");

});
