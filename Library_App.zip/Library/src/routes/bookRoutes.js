const express = require("express");
const booksRouter =  express.Router();

function router(nav){
    var books = [
        {
            title: 'The Naturalist',
            author:'Andrew Mayne',
            genre: 'Mystery',
            img :'nature.jpeg'
    
        },
        {
            title: 'The Davinci Code',
            author:'Dan Brown',
            genre: 'Mystery',
            img :'davinci.jpeg'
    
        },
        {
            title: 'The Pillars Of The Earth',
            author:'Ken Follett',
            genre: 'Novel',
            img :'earth.jpg'
    
        },
        {
            title: 'The Cloister',
            author:'James Carroll',
            genre: 'Historical Fiction',
            img :'cloister.jpg'
    
        },
        {
            title: 'Aarachar',
            author:'K.R Meera',
            genre: 'Novel',
            img :'aarachar.jpg'
    
        }
    ]
    
    
    booksRouter.get('/',function(req,res){
        res.render("books",
        {
            nav,
            title:'Library',
            books
        });
    });
    
    booksRouter.get('/:id',function(req,res){
        const id = req.params.id;
        res.render("book",
        {
            nav,
            title:'Library',
            book:books[id]
        });
    });

    return booksRouter;
    
}



module.exports = router;