var emailid = document.querySelector("#Email");
var name1 = document.querySelector("#Name");
var ph = document.querySelector("#phone");
var paswd = document.getElementById("Password");
var cpaswrd = document.querySelector("#cpaswd");
var strengthBar = document.querySelector("#strength");

var name_error = document.querySelector("#nameerror");
var email_error = document.querySelector("#emailerror");
var ph_error = document.querySelector("#pherror");
var pas_error = document.querySelector("#pswderror");
var cpas_error = document.querySelector("#cpaswderror");

let reg_email =  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
let reg_name =/[a-zA-Z]+$/;
let reg_ph = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
function validate()
{
    if(name1.value==""||emailid.value==""||paswd.value=="")
    {
        alert("please fill the fields");
        return false;
    } 
    else
    {
        return (verifyname()&&verifyemail()&&confirmpswd());

    }
}

// Name Validation

 name1.addEventListener("keyup",verifyname);

function verifyname()
    {
        if(!reg_name.test(name1.value)){
            name_error.style.color="red";
           name_error.style.fontSize="x-small";
          name_error.innerHTML="please enter your name";
        //    name1.style.border="2px solid red";
        //    name1.style.color="black";
            return false;
        }
        else{
            name_error.innerHTML="";
            name1.style.border="2px solid green";
            return true; 
        }   
       
    }

    // email validation
    emailid.addEventListener("keyup",verifyemail);

    function verifyemail()
        {
            if(!reg_email.test(emailid.value)){
                email_error.innerHTML="please enter a valid email address";
                emailid.style.border="2px solid red";
                email_error.style.color="red";
                email_error.style.fontSize="x-small";
                return false;
            }
            else{
                email_error.style.color="black";
                email_error.innerHTML=" ";
                emailid.style.border="2px solid green";
                return true;
            
            }   
        }

        //validate phone number

        ph.addEventListener("keyup",verifyph);

        function verifyph()
        {
            if(reg_ph.test(ph.value))
            {
                ph_error.innerHTML="";
                ph.style.border="2px solid green";
                return true;
            }

            else{
                ph_error.innerHTML="please enter a valid number";
                ph_error.style.color="red";
                ph_error.style.fontSize="x-small";
                ph.style.border="2px solid red";
                return false;
            }
        }


        //validate password
        paswd.addEventListener("keyup",validatepaswd);

        function validatepaswd()
        {
          var regex_pas = /^[a-zA-Z0-9]+$/;
          var regex_2 = /[!&()]/;
          var regex_3 =/[@#$*]+/;
          var strngth=0;


          if(paswd.value.length > 8)
          {
              strngth+=1;
          }

          if(paswd.value.match(regex_pas))
          {
            strngth+=1;
          }

          if(paswd.value.match(regex_2))
          {
            strngth+=1;

          }

          if(paswd.value.match(regex_3))
          {
            strngth+=1;
            console.log("hi");


          }

          console.log(strngth);

          switch(strngth)
          {
              case 0:
                  strengthBar.value=0;
                  break;

              case 1:
                  strengthBar.value=25;
                  strengthBar.innerHTML="weak";
                  strengthBar.style.backgroundColor="red";
                  break;

             case 2:
                strengthBar.value=50;
                strengthBar.style.backgroundColor="orange";
                strengthBar.innerHTML="medium";
                break;

             case 3:
                 strengthBar.value=75;
                strengthBar.style.backgroundColor="green";
                  strengthBar.innerHTML="strong";
                  break;

             case 4:
                strengthBar.value=100;
                strengthBar.style.backgroundColor="green";
                strengthBar.innerHTML="strong";
                break;
          }

        }

        //confirm password

    function confirmpswd(){
        if(paswd.value != cpaswrd.value) {
          cpaswrd.setCustomValidity("Passwords Don't Match");
        } 
        else {
          cpaswrd.setCustomValidity('');
        }
      }
      
      paswd.onchange = confirmpswd;
      cpaswrd.onkeyup = confirmpswd;

      //password toggle

      function Toggle() { 
        if (paswd.type === "password") { 
            paswd.type = "text"; 
        } 
        else { 
            paswd.type = "password"; 
        } 
    } 