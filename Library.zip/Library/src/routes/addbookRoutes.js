const express = require("express");
var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: false });
const addbookRouter =  express.Router();


function router(nav){
     
    addbookRouter.get('/', function(req, res){
        res.render('addbook',{
            nav,
            title:'Add Book'
        });
    });
    
    addbookRouter.get('/newbook', function(req, res){
        res.render('new',
        {
            nav,
            title:'new book'
        });
    });
    
    addbookRouter.post('/upload', urlencodedParser, function (req, res,next){
        upload(req, res, function (err){
            var book = req.body.book;
            var author = req.body.author;
            var genre = req.body.genre;
            var image = req.file.filename;
    
            array.push(new Book(book, author, genre, image));
            res.redirect('/');
        
        });
        });
    
    var Book = function(book, author, genre, image){
        this.book = book;
        this.author = author;
        this.genre = genre;
        this.image = image;
    }
    var array = [];


    return addbookRouter;
    
}

module.exports = router;


