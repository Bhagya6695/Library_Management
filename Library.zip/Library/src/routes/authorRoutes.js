const express = require("express");
const authorRouter =  express.Router();

function router(nav){
    var authors = [
        {
            name: 'Andrew Mayne',
            book:'The Naturalist',
            genre: 'Fiction',
            img :'andrew.jpeg'
    
        },
        {
            name: 'Dan Brown',
            book:'The Davinci Code',
            genre: 'Thriller & Mystery',
            img :'dan.jpeg'
    
        },
        {
            name: 'Ken Follett',
            book:'The Pillars Of The Earth',
            genre: 'Thriller & Historical-Fiction',
            img :'ken.jpeg'
    
        },
        {
            name: 'James Caroll',
            book:'The Cloister',
            genre: 'Fiction & History',
            img :'james.jpeg'
    
        },
        {
            name: 'K.R Meera',
            book:'Aarachar',
            genre: 'Novel & Short-story',
            img :'meera.jpeg'
    
        }
    ]
    
    
    authorRouter.get('/',function(req,res){
        res.render("authors",
        {
            nav,
            title:'Library',
            authors
        });
    });
    
    authorRouter.get('/:id',function(req,res){
        const id = req.params.id;
        res.render("author",
        {
            nav,
            title:'Library',
            author:authors[id]
        });
    });

    return authorRouter;
    
}



module.exports = router;